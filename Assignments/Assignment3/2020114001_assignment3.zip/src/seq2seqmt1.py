import torch
from torch import nn
#from langmod import lm
from tokenise import tokenize
import math
import random
from nltk.translate.bleu_score import sentence_bleu, corpus_bleu

class DataSet():
  def __init__(self, train_file):
    self.file = open(train_file, "r")
    self.vocab = []
    self.words_to_indices = {}
    self.sentences = []

    self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

  def get_vocab(self):
    freqs = {}
    nline = 0
    sentences = []
    for line in self.file:
      nline += 1
      tokens = tokenize(line)
      sentences.append(tokens)
      self.vocab += tokens

      for token in tokens:
        try: freqs[token] += 1
        except KeyError: freqs[token] = 1

      #if (nline % 1000 == 0):
      #  print("Line number", nline)

    self.vocab = list(set(self.vocab))
    self.vocab = list(filter(lambda wd: freqs[wd] >= 2, self.vocab))
    self.vocab.append('<unk>')
    self.vocab.append('<sos>')
    self.vocab.append('<eos>')

    self.words_to_indices = {word: index
                               for index, word in enumerate(self.vocab)}

    sos_index = len(self.vocab) - 2
    eos_index = len(self.vocab) - 1
    for sentence in sentences:
      self.sentences.append(torch.tensor(
                              [[sos_index] + \
                               [self.index(w) for w in sentence] + \
                               [eos_index]], device=self.device))

    print("Vocabulary created")

  def index(self, word):
    try:
      res = self.words_to_indices[word]
    except KeyError:
      res = len(self.vocab) - 3
    return res

class Encoder(nn.Module):
  def __init__(self, repr_dim, hidden_size, trainset):
    super().__init__()
    self.embedding = nn.Embedding(len(trainset.vocab), repr_dim)
    self.lstm = nn.LSTM(input_size=repr_dim,
                        hidden_size=hidden_size)
    self.trainset = trainset

    self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    self.to(self.device)

  def forward(self, src_sentence):
    embeddings = self.embedding(src_sentence)
    #print(embeddings)
    _, (output_hidden, output_cell) = self.lstm(embeddings.transpose(0,1))
    return output_hidden, output_cell

class Decoder(nn.Module):
  def __init__(self, repr_dim, hidden_size, trainset):
    super().__init__()
    self.embedding = nn.Embedding(len(trainset.vocab), repr_dim)
    self.lstm = nn.LSTM(input_size=repr_dim,
                        hidden_size=hidden_size,
                        batch_first=True)
    self.output = nn.Linear(hidden_size, len(trainset.vocab),
                            bias=False)
    self.trainset = trainset

    self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    self.to(self.device)

  def forward(self, init_hidden, init_cell, first_trg_word):
    emb = self.embedding(first_trg_word)
    next_emb, (next_hidden, next_cell) = self.lstm(torch.unsqueeze(emb, 1),
                                                   (init_hidden, init_cell))
    next_trg_words = self.output(next_emb)
    return next_trg_words, next_hidden, next_cell

class Seq2seq(nn.Module):
  def __init__(self, enc_repr_dim, dec_repr_dim, hidden_size,
                     src_trainset, trg_trainset):
    super().__init__()
    self.encoder = Encoder(enc_repr_dim, hidden_size, src_trainset)
    self.decoder = Decoder(dec_repr_dim, hidden_size, trg_trainset)

    self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    self.to(self.device)

  def forward(self, src_sentence, len_trg_sentence=0):
    enc_final_hidden, enc_final_cell = self.encoder(src_sentence)
    prob_dist, next_hidden, next_cell = self.decoder(
                                         enc_final_hidden, enc_final_cell,
                                         torch.tensor([len(self.decoder.trainset.vocab)-2],
                                                      device=self.device))

    word = prob_dist.argmax(2)

    words = [word.squeeze(0).squeeze(0)]
    output_prob_dists = [prob_dist.squeeze(0).squeeze(0)]

    i = 1

    if (len_trg_sentence > 0):
      while (i < len_trg_sentence):
        prob_dist, next_hidden, next_cell = self.decoder(
                                             next_hidden, next_cell,
                                             word.squeeze(0))
        word = prob_dist.argmax(2)
        words.append(word.squeeze(0).squeeze(0))
        output_prob_dists.append(prob_dist.squeeze(0).squeeze(0))

        i += 1
    else:
      while (word != len(self.decoder.trainset.vocab) - 1):
        prob_dist, next_hidden, next_cell = self.decoder(
                                             next_hidden, next_cell,
                                             word.squeeze(0))
        word = prob_dist.argmax(2)
        words.append(word.squeeze(0).squeeze(0))
        output_prob_dists.append(prob_dist.squeeze(0).squeeze(0))

        i += 1

        if (i >= 10):
          break

    return torch.stack(words,0), torch.stack(output_prob_dists,1)

  def translate(self, src_sentence):
    tokens = tokenize(src_sentence)
    sos_index = len(self.encoder.trainset.vocab) - 2
    eos_index = len(self.encoder.trainset.vocab) - 1

    src_indices = torch.tensor(
                    [[sos_index] + \
                     [self.encoder.trainset.index(w) for w in tokens] + \
                     [eos_index]], device=self.device)
  
    trg_indices, _ = self.forward(src_indices)
    
    trg_sentence = [self.decoder.trainset.vocab[i]
                      for i in trg_indices]
    trg_sentence.pop(0)

    return (" ".join(trg_sentence))

def train_one_epoch(model, criterion, optimiser):
  avg_epoch_loss = 0
  for i in range(len(model.encoder.trainset.sentences)):
    if (random.random() <= 0.66):
      continue

    src_sentence = model.encoder.trainset.sentences[i]
    trg_sentence = model.decoder.trainset.sentences[i].squeeze(0)

    optimiser.zero_grad()
    _, distributions = model(src_sentence, len(trg_sentence))
    distributions = distributions.transpose(0,1)

    loss = criterion(distributions, trg_sentence)
    avg_epoch_loss += loss.item()
    loss.backward()
    optimiser.step()

    if (i % 6000 == 0):
      print(i, loss.item())

  avg_epoch_loss /= len(model.encoder.trainset.sentences)
  return avg_epoch_loss

def train(model):
  criterion = nn.CrossEntropyLoss()
  optimiser = torch.optim.SGD(model.parameters(), lr=0.01, momentum=0)

  prev_loss = math.inf
  for epoch in range(100):
    avg_epoch_loss = train_one_epoch(model, criterion, optimiser)
    print("\t", epoch, avg_epoch_loss)

    if (prev_loss - avg_epoch_loss <= 0.01):
      break

def get_bleu(model, src_sentence, trg_sentence):
  src_tokens = tokenize(src_sentence)
  trg_tokens = tokenize(trg_sentence)

  score = sentence_bleu([src_tokens], trg_tokens)
  return score

def get_bleu_file(model, src_corpus, trg_corpus, bleu_filename):
  f = open(src_corpus, "r")
  g = open(trg_corpus, "r")
  h = open(bleu_filename, "w")
  line = "empty"

  lines = []
  targets = []
  while (line):
    line = f.readline()
    target = g.readline()

    lines.append([line])
    targets.append(target)

    pred = model.translate(line)
    score = get_bleu(model, pred, target)

    h.write(str(score) + '\n')
  
  corpus_score = corpus_bleu(lines, targets)
  h.seek(0,0)
  h.write(str(corpus_score) + '\n')

  f.close()
  g.close()
  h.close()

eng_train = DataSet("train.en")
fr_train = DataSet("train.fr")

eng_train.get_vocab()
fr_train.get_vocab()

mt1 = Seq2seq(100, 100, 150, eng_train, fr_train)
train(mt1)

get_bleu_file(mt1, "train.en", "train.fr", "2020114001_MT1_train.txt")
get_bleu_file(mt1, "test.en", "test.fr", "2020114001_MT1_test.txt")
